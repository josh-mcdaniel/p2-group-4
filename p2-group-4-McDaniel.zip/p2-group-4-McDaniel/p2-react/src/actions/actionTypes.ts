export const ADD_USER = 'ADD_USER';
export const LOGIN_USER = 'LOGIN_USER';
export const UPDATE_USER = "UPDATE_USER";

export const UPDATE_LEADERBOARD = 'UPDATE_LEADERBOARD'

export const UPDATE_WORDS = 'UPDATE_WORDS'



